sap.ui.define(["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.PLEASE_WAIT = void 0;
  const PLEASE_WAIT = {
    key: "PLEASE_WAIT",
    defaultText: "wait"
  };
  _exports.PLEASE_WAIT = PLEASE_WAIT;
});