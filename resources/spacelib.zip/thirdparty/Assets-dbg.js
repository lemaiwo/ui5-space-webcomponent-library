sap.ui.define(["sap/ui/webc/common/thirdparty/theming/Assets", "./generated/json-imports/Themes", "./generated/json-imports/i18n"], function (_Assets, _Themes, _i18n) {
  "use strict";
});