/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/webc/common/WebComponent","./library","./thirdparty/SpaceItemComponent"],function(e,t){"use strict";var r=e.extend("be.wl.SpaceLibrary.SpaceItemComponent",{metadata:{library:"be.wl.SpaceLibrary",tag:"space-item-component",interfaces:["be.wl.SpaceLibrary.ISpaceItemComponent"],properties:{title:{type:"string"},description:{type:"string"}}}});return r});