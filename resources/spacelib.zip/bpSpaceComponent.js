/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/webc/common/WebComponent","./library","./thirdparty/SpaceComponent"],function(e,t){"use strict";var a=e.extend("be.wl.SpaceLibrary.SpaceComponent",{metadata:{library:"be.wl.SpaceLibrary",tag:"space-component",properties:{intro:{type:"string"},height:{type:"sap.ui.core.CSSSize",mapping:"style"},width:{type:"sap.ui.core.CSSSize",mapping:"style"}},defaultAggregation:"items",aggregations:{items:{type:"be.wl.SpaceLibrary.ISpaceItemComponent",multiple:true}}}});return a});