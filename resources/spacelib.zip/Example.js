/*!
 * ${copyright}
 */
sap.ui.define(["./library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,a){"use strict";var l=e.ExampleColor;var t=r.extend("be.wl.SpaceLibrary.Example",{metadata:{library:"be.wl.SpaceLibrary",properties:{text:{type:"string",group:"Data",defaultValue:null},color:{type:"be.wl.SpaceLibrary.ExampleColor",group:"Appearance",defaultValue:l.Default}},events:{press:{}}},renderer:a,onclick:function(){this.firePress()}});return t});