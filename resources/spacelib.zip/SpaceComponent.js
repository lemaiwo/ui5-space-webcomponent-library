/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/webc/common/WebComponent","./library","./thirdparty/SpaceComponent"],function(e,t){"use strict";var a=e.extend("be.wl.SpaceLibrary.SpaceComponent",{metadata:{library:"be.wl.SpaceLibrary",tag:"space-component",properties:{height:{type:"sap.ui.core.CSSSize",mapping:"style"},intro:{type:"string",defaultValue:""},logo:{type:"string",defaultValue:""},width:{type:"sap.ui.core.CSSSize",mapping:"style"}},defaultAggregation:"items",aggregations:{items:{type:"be.wl.SpaceLibrary.SpaceItemComponent",multiple:true,slot:"items"}}}});return a});