/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/webc/common/library","./thirdparty/Assets","./library.config"],function(e){"use strict";var i=sap.ui.getCore().initLibrary({name:"be.wl.SpaceLibrary",version:"1.0.0",dependencies:["sap.ui.core","sap.ui.webc.common"],noLibraryCSS:true,designtime:"be/wl/SpaceLibrary/designtime/library.designtime",interfaces:[],types:[],controls:["be.wl.SpaceLibrary.SpaceComponent","be.wl.SpaceLibrary.SpaceItemComponent"],elements:[],extensions:{}});return i});