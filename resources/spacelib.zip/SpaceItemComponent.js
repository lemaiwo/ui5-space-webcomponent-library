/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/webc/common/WebComponent","./library","./thirdparty/SpaceItemComponent"],function(e,t){"use strict";var a=e.extend("be.wl.SpaceLibrary.SpaceItemComponent",{metadata:{library:"be.wl.SpaceLibrary",tag:"space-item-component",properties:{description:{type:"string",defaultValue:""},title:{type:"string",defaultValue:""}}}});return a});